from django.contrib import admin
from tasks.models import Task

admin.site.register(Task)
