from django import forms
from tasks.models import Task, Comment


