from django.urls import path
from tasks import views

urlpatterns = [

]

app_name = "tasks"
