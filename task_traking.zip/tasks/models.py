from django.db import models
from django.contrib.auth.models import AbstractUser
from django.urls import reverse

class CustomUser(AbstractUser):
    # Add custom fields here
    bio = models.TextField(blank=True, null=True)
    birth_date = models.DateField(blank=True, null=True)

    ROLE_CHOICES = [
        ('admin', 'Admin'),
        ('superadmin', 'Superadmin'),
        ('user', 'User'),
    ]
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='user')

    def __str__(self):
        return f"{self.username} ({self.role})"

